window.onload = writeMessage();

function writeMessage(){
    document.getElementById("Subheading").innerHTML
    = "Welcome to the website.";
    
}

function initAll() {

    document.getElementById("redirect"),
     onclick = initRedirect;
}

function initRedirect() {
    window.location = "kiwi.html"
    return false;
}